package pastyearexercise;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class PastYearExercise extends JFrame implements ItemListener, ActionListener {
    JLabel lblTitle, lblName, lblId, lblEmail, lblLevel, lblProgramName, lblSession, lblOutput;
    JTextField txtName, txtId, txtEmail;
    JTextArea txtOutput;
    JButton btnSubmit, btnView, btnReset;
    JComboBox<String> cbLevel, cbProgramName, cbSession;
    String Level[] = {"-Select-", "Diploma", "Degree"};
    String Degree[] = {"-Select-", "Degree in Manufacturing Technology", "Degree in Business Administration"};
    String Diploma[] = {"-Select-", "Diploma in Business Administration", "Diploma in Information Technology", "Diploma in Electrical Engineering",
            "Diploma in Mechanical Engineering", "Diploma in Manufacturing Engineering"};
    String Session[] = {"-Select-", "Sesi 1", "Sesi2"};


    PastYearExercise() {
        setLayout(null);
        setTitle("STUDENT ENROLLMENT SYSTEM SUNWAY UNIVERSITY");
        lblTitle = new JLabel("ENROLLMENT DATA");
        lblTitle.setForeground(Color.BLUE);
        lblTitle.setFont(new Font("VERDANA", Font.BOLD, 20));
        getContentPane().setBackground(new Color(204,204,255));

        //Declaration
        lblName = new JLabel("Name");
        lblId = new JLabel("Student ID");
        lblEmail = new JLabel("Email");
        lblLevel = new JLabel("Program Level");
        lblProgramName = new JLabel("Program Name");
        lblSession = new JLabel("Program Session");
        lblOutput = new JLabel("Output");

        txtName = new JTextField(20);

        txtName.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                char ch = e.getKeyChar();
                if (Character.isDigit(ch)) {
                    JOptionPane.showMessageDialog(null, "Letter only!");
                }
            }
        });

        txtId = new JTextField(20);
        txtEmail = new JTextField(20);

        cbLevel = new JComboBox<>(Level);
        cbProgramName = new JComboBox<>();
        cbSession = new JComboBox<>(Session);

        txtOutput = new JTextArea();
        JScrollPane spDisplay = new JScrollPane(txtOutput, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        btnSubmit = new JButton("Submit");
        btnView = new JButton("View");
        btnReset = new JButton("Reset");

        // Add listeners
        cbLevel.addItemListener(this);
        btnSubmit.addActionListener(this);
        btnView.addActionListener(this);
        btnReset.addActionListener(this);

        add(lblTitle);
        add(lblName);
        add(txtName);
        add(lblId);
        add(txtId);
        add(lblEmail);
        add(txtEmail);
        add(lblLevel);
        add(cbLevel);
        add(lblProgramName);
        add(cbProgramName);
        add(lblSession);
        add(cbSession);
        add(btnSubmit);
        add(btnView);
        add(btnReset);
        add(lblOutput);
        add(spDisplay);

        lblTitle.setBounds(150, 10, 400, 30);
        lblName.setBounds(80, 40, 100, 30);
        txtName.setBounds(190, 50, 250, 20);
        lblId.setBounds(80, 80, 100, 30);
        txtId.setBounds(190, 90, 250, 20);
        lblEmail.setBounds(80, 120, 100, 30);
        txtEmail.setBounds(190, 130, 250, 20);
        lblLevel.setBounds(80, 160, 100, 30);
        cbLevel.setBounds(190, 170, 250, 20);
        lblProgramName.setBounds(80, 200, 100, 30);
        cbProgramName.setBounds(190, 210, 250, 20);
        lblSession.setBounds(80, 240, 100, 30);
        cbSession.setBounds(190, 250, 250, 20);
        btnSubmit.setBounds(80, 290, 110, 30);
        btnView.setBounds(205, 290, 110, 30);
        btnReset.setBounds(330, 290, 110, 30);
        lblOutput.setBounds(80, 330, 100, 30);
        spDisplay.setBounds(80, 370, 360, 180);

        setSize(530, 700);
        setVisible(true);
    }

    public static void main(String[] args) {
        PastYearExercise lab = new PastYearExercise();
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (cbLevel.getSelectedItem().equals("Diploma")) {
            cbProgramName.removeAllItems();
            for (String item : Diploma) {
                cbProgramName.addItem(item);
            }
        } else if (cbLevel.getSelectedItem().equals("Degree")) {
            cbProgramName.removeAllItems();
            for (String item : Degree) {
                cbProgramName.addItem(item);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String name = txtName.getText();
        String id = txtId.getText();
        String email = txtEmail.getText();
        String level = (String) cbLevel.getSelectedItem();
        String programName = (String) cbProgramName.getSelectedItem();
        String session = (String) cbSession.getSelectedItem();

        if (e.getSource() == btnSubmit) {
            
            if (!email.contains("@gmail.com")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid email");
                return;
            }
            
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/stud_enroll", "root", "");
                Statement stat = conn.createStatement();
                
                String url = "INSERT INTO enrollment_data(name, student_id, email, program_level, program_name, session) VALUES ('" + name + "','" + id + "','"
                        + email + "','" + level + "','" + programName + "','" + session + "')";

                stat.executeUpdate(url);
                JOptionPane.showMessageDialog(null, "Data Successfully Inserted!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage());
            }
        } else if (e.getSource() == btnReset) {
            txtName.setText("");
            txtId.setText("");
            txtEmail.setText("");
            cbLevel.setSelectedIndex(0);
            cbProgramName.setSelectedIndex(0);
            cbSession.setSelectedIndex(0);
            txtOutput.setText("");
        } else if (e.getSource() == btnView) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/stud_enroll", "root", "");
                Statement stat = conn.createStatement();

                // Clear existing text before appending new data
                txtOutput.setText("");

                // Display
                String sql = "SELECT * FROM enrollment_data";
                ResultSet rs = stat.executeQuery(sql);
                while (rs.next()) {
                    txtOutput.append("Name:" + rs.getString(1) + "\n");
                    txtOutput.append("Student ID:" + rs.getString(2) + "\n");
                    txtOutput.append("Email:" + rs.getString(3) + "\n");
                    txtOutput.append("Program Level :" + rs.getString(4) + "\n");
                    txtOutput.append("Program Name :" + rs.getString(5) + "\n");
                    txtOutput.append("Program Session :" + rs.getString(6) + "\n\n\n");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage());
            }
        }
    }
}